To start the program, open the page.html file. It will open the browser to the program

Buttons
Create Polygon (Default Mode): Puts the user in Create Polygon mode. Click anywhere on the canvas to create a new vertice, indicated by a dot.
Finish Polygon: Once at least 3 vertices are on the canvas, you can click this button to create a new polygon with the current color option and line width option.
Translate: Puts the user in Translate mode. Click and drag on any polygon to move it around the screen.
Rotate: Puts the user in Rotate mode. Click and hold on a polygon and rotate it with the mouse.
Scale: Puts the user in Scale mode. Click and drag on a polygon to scale it.
Delete: Puts the user in Delete mode. Click a polygon to delete it.
Clear Canvas: Clears the canvas of all polygons and vertices.

Color Wheel: Allows the user to change the color of the next polygon created.
Line Width Input: Allows the user to change the thickness of the lines around the next created polygon.